package vn.techmasterr.jobhunt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobhuntApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobhuntApplication.class, args);
	}

}
